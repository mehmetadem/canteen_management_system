#include <iostream>
#include "tercih.h"
/* run this program using the console pauser or add your own getch, system("pause") or input loop */
using namespace std;
int main(int argc, char** argv) {
	screen a1;
	a1.anasayfa();
	
	
	return 0;
}

